const data = [
    {
        id : 1,
        title : "Stripzy™ Immunity Booster ",
        image : "./images/1.jfif",
        description : "15 Strips - Dogs and Cats and Probiotic Pet Strips Dogs and Cats and Probiotic Pet Strips ",
        price : 255,
        quantity : 1
    },
    {
        id : 2,
        title : "Wiggles Wet Food Pack of 6",
        image : "./images/2.jfif",
        description : "150g x 6 - Dogs and Puppies Pet Strips Dogs and Cats Cats and Probiotic",
        price : 594,
        quantity : 1
    },
    {
        id : 3,
        title : "YKibble™ Oven Baked Dry Food",
        image : "./images/3.jfif",
        description : "Adult Dog 3kg",
        price : 1549,
        quantity : 1
    },
    {
        id : 4,
        title : "Wiggles Peanut Butter",
        image : "./images/4.png",
        description : "200g for Dogs",
        price : 299,
        quantity : 1
    },

    {
        id : 5,
        title : "Wiggles Emergency Care Kit",
        image : "./images/5.png",
        description : "Dogs and Cats",
        price : 2499,
        quantity : 1
    },
    
    {
        id : 6,
        title : "Deworminator™ Dewormer",
        image : "./images/6.png",
        description : "1 X 10 Tablets- Dogs and Puppies",
        price : 500,
        quantity : 1
    },


]

export default data