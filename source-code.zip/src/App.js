import React, {Suspense} from 'react';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import './App.css';
import './components/cart.css';
import Footer from './components/Footer';
import Header from './components/Header';
//import ProductDetailView from './components/ProductDetailView';
//import Cart from './components/Cart';
//import HomeScreen from './Screens/HomeScreen';
const HomeScreen = React.lazy(()=>import('./Screens/HomeScreen'));
const Cart = React.lazy(()=>import('./components/Cart'));
const ProductDetailView = React.lazy(()=>import('./components/ProductDetailView'));

const App =()=> {
    
  return (
    <div className="App">
      

      <Router>
      <Header/>
        <Suspense fallback={<div className="centered">
            Loading...
          </div>}>
          <Switch>
            <Route path="/cart">
                <Cart />
            </Route>
            <Route path="/product/:pid" >
                <ProductDetailView />
            </Route>
            <Route path="/">
                <HomeScreen />
            </Route>
          </Switch>
        </Suspense>
      <Footer/>
    </Router>
      
      
      
      

            
    </div>
  );
}

export default App;
