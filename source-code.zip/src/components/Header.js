import React, { useContext } from 'react';
import CartContext from '../context/cart/CartContext';
import {Link} from "react-router-dom";
import ReactTooltip from 'react-tooltip';


const Header = () => {
    
    const {cartItems} = useContext(CartContext);

    return(
        <><ReactTooltip place="bottom" type="dark" effect="float"/>
        <header>
            
            <div className="wiggles-header-logo">
                <Link to={`/`}><h1>Wiggles Mall</h1></Link>   
            </div>
            <div className="cart-icon">
                <Link to={`/cart`} data-tip = "View Cart">
                    <i className="fas fa-shopping-cart"></i>
                    <p>{cartItems.length}</p>
                </Link>
                
            </div>
        </header>
        </>
    )
}

export default Header;