import React, { useContext, useState, useEffect } from 'react';
import CartContext from '../context/cart/CartContext';
import CartItem from './CartItem';
import {Link} from 'react-router-dom'

import './cart.css';

const Cart = () =>{
    const {cartItems} = useContext(CartContext)
    
     
    return(
        <>
        <section className="main-cart-section">
            <div className="sub-heading">
                <h1 className="pro-heading">View Cart 
                    <small>
                        <Link to={`/`}><i className="fas fa-long-arrow-alt-left"></i> Go to Home</Link>
                    </small>
                    
                </h1>
            </div>
            <div className="cart-items">
                <div className="cart-items-container">
                    {
                        cartItems.length === 0 ? 
                        (<h2 className="text-danger">Cart is Empty</h2>) : 
                        (
                            <>
                                {
                                cartItems.map(item=>(
                                    <CartItem key={item.id} item={item} />
                                ))
                                }
                                 
                            </>
                        )
                    }
                    
                </div>
            </div>
            
        </section>
        <section className="card-total">
                <h3> Cart Total: <span>$ {cartItems.reduce((amt,item)=> item.price + amt, 0)}</span></h3>
                <button>Checkout</button>
            </section>
            </>
    )

}

export default Cart