import { useContext } from "react";
import {
    Link
} from "react-router-dom";
import CartContext from "../context/cart/CartContext";

const ProductList = ({product}) => {
    const {addToCart} = useContext(CartContext);
    return (
        
            <div className="product-listing">
                <div className="product-img">
                    <img src={product.image} alt=""/>
                </div>
                <div className="title">
                    <h4>{product.title}</h4>
                    <p>{product.description}</p>
                </div>
                <div className="price">
                    <h3>$ {product.price}</h3>
                </div>
                <div className="nav-buttons">
                    <Link className="btn" to={`/product/${product.id}`}>View Detail</Link>
                    <button className="btn btn-primary" onClick={()=>addToCart(product)}>Add to Cart</button>
                </div>
            </div>
            
        
    )
}

export default ProductList