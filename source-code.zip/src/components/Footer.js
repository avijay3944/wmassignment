import React from 'react';

const Footer = () => {
    return (
        <footer>
            <h1> Footer goes here...</h1>      
        </footer>
    )
}

export default Footer
