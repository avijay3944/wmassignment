import { useContext, useState} from "react";
import CartContext from "../context/cart/CartContext";

const CartItem = ({ item }) => {
     
    const {removeItem} = useContext(CartContext);
    
    const [quan, setQuan] = useState(item.quantity)
    const increment = () =>{
        setQuan(quan + 1)
    }
    const decrement = () =>{
        setQuan(quan - 1)
        if(quan === 1) removeItem(item.id)
    }
      
        

    return (
        <>
            <div className="items-info">
                        <div className="product-img">
                            <img src={item.image} alt=""/>
                        </div>
                        <div className="title">
                            <h2>{item.title}</h2>
                        </div>
                        <div className="add-minus-quantity">
                            <i className="fas fa-minus minus hide" onClick={decrement}></i>
                            <input type="text" placeholder={quan} disabled/>
                            <i className="fas fa-plus plus hide" onClick={increment}></i>
                        </div>
                        <div className="price">
                                <h3>$ {item.price * quan}</h3>
                        </div>
                        <div className="remove-item">
                            <i className="fas fa-trash-alt remove" onClick={()=> removeItem(item.id)}></i>
                        </div>
                    </div>
            <hr/>
        </>
    )
}

export default CartItem