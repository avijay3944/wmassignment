import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import products from '../data';


const ProductDetailView = () => {
    const { pid } = useParams();
    //console.log("pid" , pid)
    
    const [productItem, setProductItem] = useState(products.find((item)=>{
        return item.id == pid
    }))
    return (
        <>
            <div className="main-cart-section">
                <div className="sub-heading">
                    <h1 className="pro-heading">Product Detail view 
                        <small>
                            <Link to={`/`}><i className="fas fa-long-arrow-alt-left"></i> Go to Home</Link>
                        </small>
                        
                    </h1>
                </div>
                <div className="flex-container detail-view">
                        <>  
                            <div>
                                <img src={productItem.image} alt=""/>
                            </div>
                            <div>
                                <h1>{productItem.title}</h1>
                                <p><strong>Description:</strong> {productItem.description}</p>
                                <p><strong>Price Per Item:</strong> {productItem.price}</p>
                                <p><strong>Quantity Available:</strong> {productItem.quantity}</p>
                            </div>
                        </>
                </div>
            </div>   
        </>
    )
}
export default ProductDetailView