import products from '../data';
import ProductList from '../components/ProductList';

const HomeScreen = () => {
    return (
        
        <section className="main-cart-section flex-container">
            {
                products.map((product) =>  (
                    <ProductList key = {product.id} product = {product} />
                ))
            }
        </section>
        
    )
}
export default HomeScreen