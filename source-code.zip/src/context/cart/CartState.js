import { useReducer } from "react";
import { REMOVE_ITEM, ADD_TO_CART, VIEW_DETAIL } from "../Types";
import CartContext from "./CartContext";
import CartReducer from "./CartReducer";


const CartState = ({ children }) => {
    
    const initialState = {
        cartItems : []
    }

    const [state, dispatch] = useReducer(CartReducer, initialState);

    const addToCart = item => {
        dispatch({type: ADD_TO_CART, payload: item})
    }


    const removeItem = id => {
        dispatch({type:REMOVE_ITEM, payload:id})
    }

     

    const viewDetail = id =>{
        dispatch({type: VIEW_DETAIL, payload: id})
    }

    return (
        <CartContext.Provider value={{
            cartItems:state.cartItems, 
            addToCart , 
            removeItem,
            viewDetail
            }}  
        >
            {children}          
        </CartContext.Provider>
    
    );
};

export default CartState